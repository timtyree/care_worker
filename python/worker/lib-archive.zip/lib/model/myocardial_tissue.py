#@njit
def time_step_at_shape_at_pixel(self, h, neighboring_ids):
	'''maybe this task is best outside of this .py file. use trimesh in a different myocardial_tissue.py'''
	#TODO: define mechanical parameters from kwargs
	neighboring_ids   = self.get_neighboring_ids()
	
	#TODO: make this call asynchronous when all neighbors are at least up to date with vertex_id
	if self.neighbors_up_to_date(neighboring_ids):
		pass

	#TODO: after asynchronous call is completed, update time
	#TODO
	return self