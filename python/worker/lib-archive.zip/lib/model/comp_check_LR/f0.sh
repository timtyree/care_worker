#!/bin/bash
#Compiles fortran .f to executable .x
#not working?
gfortran !:1.f -o !:1.x
